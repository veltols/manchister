@extends('layouts.app')

@section('title', 'Messaging Center')
@section('subtitle', 'Stay connected with your team')

@section('content')
<div class="h-[calc(100vh-12rem)] flex gap-6 animate-fade-in-up" x-data="{ searchQuery: '' }">
    <!-- Chat Sidebar -->
    <div class="w-80 bg-white rounded-[2rem] shadow-lg shadow-slate-200/50 border border-slate-100 flex flex-col overflow-hidden">
        <!-- Sidebar Header -->
        <div class="p-6 border-b border-slate-100 bg-slate-50/50">
            <div class="flex justify-between items-center mb-4">
                <h3 class="font-display font-bold text-slate-800">Direct Messages</h3>
                <button onclick="openModal('newChatModal')" class="w-8 h-8 rounded-lg bg-brand hover:brightness-110 text-white flex items-center justify-center transition-all shadow-sm shadow-brand/20">
                    <i class="fa-solid fa-plus text-sm"></i>
                </button>
            </div>
            <div class="relative group">
                 <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand transition-colors"></i>
                <input type="text" x-model="searchQuery" placeholder="Search conversations..." class="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-brand transition-colors">
            </div>
        </div>

        <!-- Conversation List -->
        <div class="flex-1 overflow-y-auto">
            @foreach($conversations as $conv)
                @php
                    $otherUser = ($conv->participantA->employee_id ?? 0) == auth()->user()->employee->employee_id 
                                ? $conv->participantB 
                                : $conv->participantA;
                    $isActive = isset($conversation) && $conversation->chat_id == $conv->chat_id;
                @endphp
                <a href="{{ route('emp.messages.show', $conv->chat_id) }}" 
                   class="flex items-center gap-3 p-4 hover:bg-slate-50 transition-colors border-b border-slate-50 {{ $isActive ? 'bg-brand/5 border-l-4 border-l-brand' : 'border-l-4 border-l-transparent' }}">
                    <div class="relative">
                        <div class="w-12 h-12 rounded-full bg-brand/10 text-brand flex items-center justify-center font-bold text-lg border border-brand/20 overflow-hidden">
                            @if($otherUser && $otherUser->employee_picture)
                                <img src="{{ asset('uploads/'.$otherUser->employee_picture) }}" class="w-full h-full object-cover">
                            @else
                                {{ strtoupper(substr($otherUser->first_name ?? '?', 0, 1)) }}
                            @endif
                        </div>
                        <div class="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></div>
                        @if($conv->unread_count > 0)
                            <div class="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 border-2 border-white flex items-center justify-center text-[10px] font-bold text-white shadow-sm unread-badge">
                                {{ $conv->unread_count }}
                            </div>
                        @endif
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex justify-between items-baseline mb-1">
                            <h4 class="font-bold text-slate-700 truncate {{ $isActive ? 'text-brand' : '' }}">
                                {{ $otherUser->first_name ?? 'Unknown' }} {{ $otherUser->last_name ?? '' }}
                            </h4>
                            <span class="text-[10px] text-slate-400 font-medium whitespace-nowrap">
                                {{ $conv->messages->last() ? \Carbon\Carbon::parse($conv->messages->last()->added_date)->format('h:i A') : '' }}
                            </span>
                        </div>
                        <p class="text-xs text-slate-500 truncate">
                            {{ $conv->messages->last()->post_text ?? 'Start a conversation...' }}
                        </p>
                    </div>
                </a>
            @endforeach
        </div>
    </div>

    <!-- Chat Area -->
    <div class="flex-1 bg-white rounded-[2rem] shadow-lg shadow-slate-200/50 border border-slate-100 flex flex-col overflow-hidden relative">
        @if(isset($conversation))
            @php
                $activeOtherUser = ($conversation->participantA->employee_id ?? 0) == auth()->user()->employee->employee_id 
                                ? $conversation->participantB 
                                : $conversation->participantA;
            @endphp
            
            <!-- Chat Header -->
            <div class="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-brand/10 text-brand flex items-center justify-center font-bold border border-brand/20 overflow-hidden">
                        @if($activeOtherUser && $activeOtherUser->employee_picture)
                            <img src="{{ asset('uploads/'.$activeOtherUser->employee_picture) }}" class="w-full h-full object-cover">
                        @else
                            {{ strtoupper(substr($activeOtherUser->first_name ?? '?', 0, 1)) }}
                        @endif
                    </div>
                    <div>
                        <h3 class="font-bold text-slate-800">{{ $activeOtherUser->first_name ?? 'Unknown' }} {{ $activeOtherUser->last_name ?? '' }}</h3>
                        @if($activeOtherUser && $activeOtherUser->status)
                            <div class="flex items-center gap-1.5">
                                <div class="w-2 h-2 rounded-full shadow-[0_0_8px_rgba(0,0,0,0.1)]" style="background-color: {{ $activeOtherUser->status->staus_color }}"></div>
                                <span class="text-xs text-slate-500 font-medium">{{ $activeOtherUser->status->staus_name }}</span>
                            </div>
                        @else
                             <div class="flex items-center gap-1.5">
                                <div class="w-2 h-2 rounded-full bg-slate-300"></div>
                                <span class="text-xs text-slate-500 font-medium">Offline</span>
                            </div>
                        @endif
                    </div>
                </div>
                
            </div>

            <!-- Messages Container -->
            <div class="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30 scrollbar-hide" id="messagesContainer">
                @foreach($messages as $msg)
                    @php $isMine = $msg->added_by == auth()->user()->employee->employee_id; @endphp
                    <div id="msg-{{ $msg->post_id }}" class="flex w-full {{ $isMine ? 'justify-end' : 'justify-start' }}">
                        <div class="flex max-w-[70%] {{ $isMine ? 'flex-row-reverse' : 'flex-row' }} gap-3">
                             @if(!$isMine)
                                <div class="w-8 h-8 rounded-full bg-brand/10 flex-shrink-0 flex items-center justify-center overflow-hidden self-end border border-brand/20">
                                    @if($msg->sender && $msg->sender->employee_picture)
                                         <img src="{{ asset('uploads/' . $msg->sender->employee_picture) }}" class="w-full h-full object-cover">
                                    @else
                                        <span class="text-[10px] font-bold text-brand">{{ substr($msg->sender->first_name ?? '?', 0, 1) }}</span>
                                    @endif
                                </div>
                            @endif
                            
                            <div class="flex flex-col {{ $isMine ? 'items-end' : 'items-start' }}">
                                <div class="px-5 py-3 rounded-2xl {{ $isMine ? 'bg-brand text-white rounded-br-none shadow-brand/10' : 'bg-white border border-slate-100 text-slate-700 rounded-bl-none shadow-sm' }} shadow-md">
                                    @if($msg->post_type == 'text')
                                        <p class="text-sm leading-relaxed">{{ $msg->post_text }}</p>
                                    @elseif($msg->post_type == 'image')
                                        <img src="{{ asset('uploads/'.$msg->post_text) }}" class="rounded-lg max-w-xs transition-opacity hover:opacity-90 cursor-pointer" onclick="window.open(this.src)">
                                    @elseif($msg->post_type == 'document')
                                        <a href="{{ asset('uploads/'.$msg->post_text) }}" target="_blank" class="flex items-center gap-3 p-2 rounded-xl {{ $isMine ? 'bg-white/10 text-white' : 'bg-slate-50 text-slate-700' }} no-underline hover:bg-white/20 transition-colors">
                                            <div class="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                                                <i class="fa-solid fa-file-invoice text-lg"></i>
                                            </div>
                                            <div class="flex flex-col min-w-0">
                                                <span class="text-xs font-bold truncate max-w-[150px]">{{ $msg->post_text }}</span>
                                                <span class="text-[10px] opacity-70">Document</span>
                                            </div>
                                        </a>
                                    @endif
                                </div>
                                <span class="text-[10px] text-slate-400 mt-1 font-medium px-1 uppercase tracking-tighter">
                                    {{ \Carbon\Carbon::parse($msg->added_date)->format('h:i A') }}
                                </span>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Input Area -->
            <div class="p-4 bg-white border-t border-slate-100">
                <div id="chat-attachment-preview" class="px-4 mb-2"></div>
                <form action="{{ route('emp.messages.reply', $conversation->chat_id) }}" method="POST" enctype="multipart/form-data" class="flex items-end gap-3" x-data="{ hasFile: false }">
                    @csrf
                    <label class="w-10 h-10 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-400 transition-colors flex-shrink-0 flex items-center justify-center cursor-pointer">
                        <i class="fa-solid fa-paperclip" :class="{ 'has-file': hasFile }"></i>
                        <input type="file" name="attachment" id="chat_attachment" class="hidden" @change="hasFile = true">
                    </label>
                    
                    <div class="flex-1 bg-slate-50 rounded-xl border border-slate-200 transition-all">
                        <textarea name="post_text" rows="1" placeholder="Type your message..." class="w-full bg-transparent border-none focus:ring-0 px-4 py-3 text-sm text-slate-700 resize-none max-h-32 scrollbar-hide" oninput="this.style.height = ''; this.style.height = this.scrollHeight + 'px'"></textarea>
                    </div>

                    <button type="submit" class="w-10 h-10 rounded-xl bg-brand hover:brightness-110 text-white shadow-lg shadow-brand/20 transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center flex-shrink-0">
                        <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </form>
            </div>
            
            <script>
                // Auto-scroll to bottom on page load
                const container = document.getElementById('messagesContainer');
                if (container) {
                    container.scrollTop = container.scrollHeight;
                }

                @if(isset($conversation))
                // Real-time messaging variables
                let lastMessageId = {{ $messages->last()->post_id ?? 0 }};
                const chatId = {{ $conversation->chat_id }};
                const currentUserId = {{ auth()->user()->employee->employee_id ?? 0 }};
                let pollingInterval;

                // Poll for new messages every 3 seconds
                function pollNewMessages() {
                    fetch(`/emp/messages/${chatId}/fetch?last_message_id=${lastMessageId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.messages.length > 0) {
                                data.messages.forEach(msg => {
                                    appendMessage(msg);
                                    lastMessageId = msg.post_id;
                                });
                                
                                // Scroll to bottom
                                container.scrollTop = container.scrollHeight;
                            }
                        })
                        .catch(error => console.error('Error fetching messages:', error));
                }

                // Append new message to chat
                function appendMessage(msg) {
                    // Prevent duplicates
                    if (document.getElementById(`msg-${msg.post_id}`)) return;

                    const isMine = msg.added_by == currentUserId;
                    
                    let contentHtml = '';
                    if (msg.post_type === 'image') {
                        contentHtml = `<img src="/uploads/${msg.post_text}" class="rounded-lg max-w-xs transition-opacity hover:opacity-90 cursor-pointer" onclick="window.open(this.src)">`;
                    } else if (msg.post_type === 'document') {
                        contentHtml = `
                            <a href="/uploads/${msg.post_text}" target="_blank" class="flex items-center gap-3 p-2 rounded-xl ${isMine ? 'bg-white/10 text-white' : 'bg-slate-50 text-slate-700'} no-underline hover:bg-white/20 transition-colors">
                                <div class="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                                    <i class="fa-solid fa-file-invoice text-lg"></i>
                                </div>
                                <div class="flex flex-col min-w-0">
                                    <span class="text-xs font-bold truncate max-w-[150px]">${msg.post_text}</span>
                                    <span class="text-[10px] opacity-70">Document</span>
                                </div>
                            </a>`;
                    } else {
                        contentHtml = `<p class="text-sm leading-relaxed">${msg.post_text}</p>`;
                    }

                    const messageHtml = `
                        <div id="msg-${msg.post_id}" class="flex w-full ${isMine ? 'justify-end' : 'justify-start'} animate-fade-in-up">
                            <div class="flex max-w-[70%] ${isMine ? 'flex-row-reverse' : 'flex-row'} gap-3">
                                ${!isMine ? `
                                    <div class="w-8 h-8 rounded-full bg-brand/10 flex-shrink-0 flex items-center justify-center overflow-hidden self-end border border-brand/20">
                                        ${msg.sender && msg.sender.employee_picture ? 
                                            `<img src="/uploads/${msg.sender.employee_picture}" class="w-full h-full object-cover">` :
                                            `<span class="text-[10px] font-bold text-brand">${msg.sender ? msg.sender.first_name.charAt(0) : '?'}</span>`
                                        }
                                    </div>
                                ` : ''}
                                
                                <div class="flex flex-col ${isMine ? 'items-end' : 'items-start'}">
                                    <div class="px-5 py-3 rounded-2xl ${isMine ? 'bg-brand text-white rounded-br-none shadow-brand/10' : 'bg-white border border-slate-100 text-slate-700 rounded-bl-none shadow-sm'} shadow-md">
                                        ${contentHtml}
                                    </div>
                                    <span class="text-[10px] text-slate-400 mt-1 font-medium px-1 uppercase tracking-tighter">
                                        ${new Date(msg.added_date).toLocaleTimeString('en-US', {hour: '2-digit', minute: '2-digit'})}
                                    </span>
                                </div>
                            </div>
                        </div>
                    `;
                    container.insertAdjacentHTML('beforeend', messageHtml);
                }

                // Start polling
                pollingInterval = setInterval(pollNewMessages, 3000);

                // Send message via Ajax
                const messageForm = document.querySelector('form[action="{{ route('emp.messages.reply', $conversation->chat_id) }}"]');
                if (messageForm) {
                    messageForm.addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        const formData = new FormData(this);
                        // Validate: Either text or file must exist
                        const messageText = formData.get('post_text');
                        // Use the file input element to check
                        const fileInput = this.querySelector('input[name="attachment"]');
                        const hasFile = fileInput && fileInput.files.length > 0;
                        
                        if ((!messageText || !messageText.trim()) && !hasFile) return;
                        
                        // Disable submit button
                        const submitBtn = this.querySelector('button[type="submit"]');
                        if(submitBtn) submitBtn.disabled = true;
                        
                        fetch(this.action, {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Message sent successfully
                                appendMessage(data.message);
                                lastMessageId = data.message.post_id;
                                
                                // Scroll to bottom
                                container.scrollTop = container.scrollHeight;

                                // Clear inputs
                                const textArea = this.querySelector('textarea[name="post_text"]');
                                if(textArea) {
                                    textArea.value = '';
                                    textArea.style.height = '';
                                }
                                
                                // Reset file input and Alpine state
                                if(fileInput) fileInput.value = '';
                                
                                // Reset preview using the exposed method if available or manually
                                const previewContainer = document.getElementById('chat-attachment-preview');
                                if(previewContainer) previewContainer.innerHTML = '';
                                
                                // If using Alpine for "hasFile", try to reset it.
                                // Since we are outside Alpine scope, we rely on the input change event or manual DOM update.
                                // However, since we cleared value, future changes trigger event.
                                
                                // Re-enable submit button
                                if(submitBtn) submitBtn.disabled = false;
                            } else {
                                console.error('Server returned error:', data);
                                if(submitBtn) submitBtn.disabled = false;
                            }
                        })
                        .catch(error => {
                            console.error('Error sending message:', error);
                            if(submitBtn) submitBtn.disabled = false;
                        });
                    });
                }

                // Stop polling when leaving page
                window.addEventListener('beforeunload', function() {
                    clearInterval(pollingInterval);
                });
                @endif

                // Poll conversation list for unread count updates (every 5 seconds)
                function updateConversationList() {
                    fetch('/emp/messages-conversation-list')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                console.log('Conversation list data:', data);
                                const conversationContainer = document.querySelector('.flex-1.overflow-y-auto');
                                if (!conversationContainer) {
                                    console.error('Conversation container not found');
                                    return;
                                }

                                // Sort conversations: unread first, then by chat_id (most recent)
                                const sortedConversations = data.conversations.sort((a, b) => {
                                    if (a.unread_count > 0 && b.unread_count === 0) return -1;
                                    if (a.unread_count === 0 && b.unread_count > 0) return 1;
                                    return b.chat_id - a.chat_id;
                                });

                                console.log('Sorted conversations:', sortedConversations);

                                // Update each conversation
                                sortedConversations.forEach((conv, index) => {
                                    const convLink = document.querySelector(`a[href="/emp/messages/${conv.chat_id}"]`);
                                    
                                    if (convLink) {
                                        // The <a> tag itself is the list item
                                        const listItem = convLink;
                                        
                                        // Move to correct position
                                        const currentIndex = Array.from(conversationContainer.children).indexOf(listItem);
                                        if (currentIndex !== index && currentIndex !== -1) {
                                            console.log(`Moving conversation ${conv.chat_id} from position ${currentIndex} to ${index}`);
                                            conversationContainer.insertBefore(listItem, conversationContainer.children[index]);
                                        }
                                        
                                        // Update badge
                                        let badgeContainer = convLink.querySelector('.unread-badge');
                                        
                                        if (conv.unread_count > 0) {
                                            if (badgeContainer) {
                                                // Update existing badge
                                                if (badgeContainer.textContent !== conv.unread_count.toString()) {
                                                    console.log(`Updating badge for conversation ${conv.chat_id} to ${conv.unread_count}`);
                                                    badgeContainer.textContent = conv.unread_count;
                                                    // Add pulse animation
                                                    badgeContainer.style.animation = 'pulse 0.5s';
                                                    setTimeout(() => badgeContainer.style.animation = '', 500);
                                                }
                                            } else {
                                                // Create new badge
                                                console.log(`Creating new badge for conversation ${conv.chat_id} with count ${conv.unread_count}`);
                                                const avatarDiv = convLink.querySelector('.relative');
                                                if (avatarDiv) {
                                                    const newBadge = document.createElement('div');
                                                    newBadge.className = 'absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 border-2 border-white flex items-center justify-center text-[10px] font-bold text-white shadow-sm unread-badge';
                                                    newBadge.textContent = conv.unread_count;
                                                    avatarDiv.appendChild(newBadge);
                                                }
                                            }
                                        } else {
                                            // Remove badge if count is 0
                                            if (badgeContainer) {
                                                console.log(`Removing badge for conversation ${conv.chat_id}`);
                                                badgeContainer.remove();
                                            }
                                        }
                                    } else {
                                        console.warn(`Conversation link not found for chat_id ${conv.chat_id}`);
                                    }
                                });
                            }
                        })
                        .catch(error => console.error('Error updating conversation list:', error));
                }

                // Poll every 5 seconds
                setInterval(updateConversationList, 5000);
                
                // Initial call
                updateConversationList();
            </script>

        @else
            <!-- Empty State -->
            <div class="flex-1 flex flex-col items-center justify-center text-slate-300 p-12 text-center">
                <div class="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mb-6 shadow-sm">
                    <i class="fa-regular fa-paper-plane text-4xl text-brand/30"></i>
                </div>
                <h3 class="text-xl font-display font-bold text-slate-400">Messaging Hub</h3>
                <p class="text-sm text-slate-400 mt-2 max-w-xs">Connect with your team instantly. Select a conversation to start chatting.</p>
            </div>
        @endif
    </div>
</div>

<!-- New Chat Modal -->
<div id="newChatModal" class="modal">
    <div class="modal-backdrop" @click="closeModal('newChatModal')"></div>
    <div class="modal-content w-full max-w-md p-0 overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 class="text-xl font-display font-bold text-slate-800">Start New Chat</h3>
            <button onclick="closeModal('newChatModal')" class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-400 transition-colors">
                <i class="fa-solid fa-times"></i>
            </button>
        </div>

        <form action="{{ route('emp.messages.store') }}" method="POST" class="p-8">
            @csrf
            <div class="mb-8">
                <label class="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Target Colleague</label>
                <div class="relative group">
                    <i class="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand transition-colors"></i>
                    <select name="employee_id" class="w-full premium-input pl-12 h-12 text-sm" required>
                        <option value="">Choose a colleague...</option>
                        @foreach($employees as $emp)
                            <option value="{{ $emp->employee_id }}">{{ $emp->first_name }} {{ $emp->last_name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="flex gap-3">
                <button type="button" onclick="closeModal('newChatModal')" class="flex-1 px-6 py-3.5 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all">Cancel</button>
                <button type="submit" class="flex-1 px-6 py-3.5 rounded-xl bg-brand text-white font-bold shadow-xl shadow-brand/20 hover:scale-[1.02] active:scale-95 transition-all">
                    Start Chatting
                </button>
            </div>
        </form>
    </div>
</div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.4.2/mammoth.browser.min.js"></script>
    <script src="{{ asset('js/attachment-preview.js') }}"></script>
    <script>
        // Initialize Attachment Preview for Chat
        window.initAttachmentPreview({
            inputSelector: '#chat_attachment',
            containerSelector: '#chat-attachment-preview',
            onRemove: () => {
                // Sync with Alpine state if possible, though not strictly required for purely visual preview
                // We'll use a custom property on the input if needed, but let's keep it simple
            }
        });
    </script>
@endsection
