<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AtpLog extends Model
{
    use HasFactory;

    protected $table = 'atps_list_logs';
    protected $primaryKey = 'log_id';
    public $timestamps = false;

    protected $guarded = [];

    public function atp()
    {
        return $this->belongsTo(Atp::class, 'atp_id', 'atp_id');
    }

    public function logger()
    {
        return $this->belongsTo(Employee::class, 'logged_by', 'employee_id');
    }
}
