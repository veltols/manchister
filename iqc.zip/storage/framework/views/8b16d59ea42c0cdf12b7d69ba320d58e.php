<?php $__env->startSection('title', 'Designations'); ?>
<?php $__env->startSection('subtitle', 'Manage job titles and hierarchy'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">

        <!-- Structure Navigation -->
        <?php echo $__env->make('hr.partials.structure_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Header with Action Button -->
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-2xl font-display font-bold text-premium">Designations</h2>
                <p class="text-sm text-slate-500 mt-1"><?php echo e($designations->total()); ?> total designations</p>
            </div>
            <button onclick="openModal('addDesignationModal')"
                class="inline-flex items-center gap-2 px-6 py-3 premium-button bg-gradient-brand text-white font-semibold rounded-xl shadow-lg shadow-brand/20 hover:shadow-brand/40 hover:scale-105 transition-all duration-200">
                <i class="fa-solid fa-plus"></i>
                <span>Add Designation</span>
            </button>
        </div>

        <!-- Designations Table -->
        <div class="premium-card overflow-hidden">
            <div class="overflow-x-auto">
                <table class="premium-table w-full">
                    <thead>
                        <tr>
                            <th class="text-left">Ref</th>
                            <th class="text-left">Code</th>
                            <th class="text-left">Name</th>
                            <th class="text-left">Department</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="designations-container">
                        <?php $__empty_1 = true; $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><span
                                        class="font-mono text-sm font-semibold text-slate-600">#<?php echo e($designation->designation_id); ?></span>
                                </td>
                                <td><span
                                        class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-50 text-indigo-800 text-sm font-bold"><?php echo e($designation->designation_code); ?></span>
                                </td>
                                <td><span class="font-semibold text-slate-800"><?php echo e($designation->designation_name); ?></span></td>
                                <td>
                                    <?php if($designation->department): ?>
                                        <span
                                            class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-50 text-purple-700 text-sm font-medium">
                                            <i class="fa-solid fa-building text-xs"></i>
                                            <?php echo e($designation->department->department_name); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-red-400 text-sm italic">No Department</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="flex items-center justify-center">
                                        <button
                                            onclick="editDesignation(<?php echo e($designation->designation_id); ?>, '<?php echo e(addslashes($designation->designation_code)); ?>', '<?php echo e(addslashes($designation->designation_name)); ?>', <?php echo e($designation->department_id ?? 0); ?>)"
                                            class="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center hover:scale-110 transition-all shadow-md"
                                            title="Edit">
                                            <i class="fa-solid fa-pen text-sm"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-12">
                                    <div class="flex flex-col items-center gap-3">
                                        <div class="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center">
                                            <i class="fa-solid fa-briefcase text-2xl text-slate-400"></i>
                                        </div>
                                        <p class="text-slate-500 font-medium">No designations found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- AJAX Pagination Container -->
            <div id="designations-pagination"></div>
        </div>

    </div>

    <!-- Add Designation Modal -->
    <div class="modal" id="addDesignationModal">
        <div class="modal-backdrop" onclick="closeModal('addDesignationModal')"></div>
        <div class="modal-content p-8">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-display font-bold text-premium">Add New Designation</h2>
                <button onclick="closeModal('addDesignationModal')"
                    class="w-10 h-10 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors">
                    <i class="fa-solid fa-times text-xl"></i>
                </button>
            </div>

            <form action="<?php echo e(route(request()->is('admin*') ? 'admin.designations.store' : 'hr.designations.store')); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Code</label>
                        <input type="text" name="designation_code" class="premium-input w-full px-4 py-3 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Name</label>
                        <input type="text" name="designation_name" class="premium-input w-full px-4 py-3 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Department</label>
                        <select name="department_id" class="premium-input w-full px-4 py-3 text-sm" required>
                            <option value="">Select Department</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->department_id); ?>"><?php echo e($d->department_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Remarks</label>
                        <textarea name="log_remark" class="premium-input w-full px-4 py-3 text-sm" rows="3"
                            placeholder="Optional remarks..."></textarea>
                    </div>
                </div>

                <div class="flex justify-end gap-3 mt-6 pt-6 border-t border-slate-200">
                    <button type="button" onclick="closeModal('addDesignationModal')"
                        class="px-6 py-3 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold transition-colors">Cancel</button>
                    <button type="submit"
                        class="px-6 py-3 premium-button bg-gradient-brand text-white font-semibold rounded-xl shadow-lg shadow-brand/20 hover:shadow-brand/40 hover:scale-105 transition-all duration-200">Create</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Designation Modal -->
    <div class="modal" id="editDesignationModal">
        <div class="modal-backdrop" onclick="closeModal('editDesignationModal')"></div>
        <div class="modal-content p-8">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-display font-bold text-premium">Edit Designation</h2>
                <button onclick="closeModal('editDesignationModal')"
                    class="w-10 h-10 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors">
                    <i class="fa-solid fa-times text-xl"></i>
                </button>
            </div>

            <form id="editDesignationForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Code</label>
                        <input type="text" name="designation_code" id="edit_designation_code"
                            class="premium-input w-full px-4 py-3 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Name</label>
                        <input type="text" name="designation_name" id="edit_designation_name"
                            class="premium-input w-full px-4 py-3 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Department</label>
                        <select name="department_id" id="edit_department_id" class="premium-input w-full px-4 py-3 text-sm"
                            required>
                            <option value="">Select Department</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->department_id); ?>"><?php echo e($d->department_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Remarks <span
                                class="text-red-500">*</span></label>
                        <textarea name="log_remark" id="edit_designation_remark"
                            class="premium-input w-full px-4 py-3 text-sm" rows="3" required
                            placeholder="Reason for update..."></textarea>
                    </div>
                </div>

                <div class="flex justify-end gap-3 mt-6 pt-6 border-t border-slate-200">
                    <button type="button" onclick="closeModal('editDesignationModal')"
                        class="px-6 py-3 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold transition-colors">Cancel</button>
                    <button type="submit"
                        class="px-6 py-3 premium-button bg-gradient-brand text-white font-semibold rounded-xl shadow-lg shadow-brand/20 hover:shadow-brand/40 hover:scale-105 transition-all duration-200">Update</button>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/ajax-pagination.js')); ?>"></script>
        <script>
            function editDesignation(id, code, name, deptId) {
                document.getElementById('edit_designation_code').value = code;
                document.getElementById('edit_designation_name').value = name;
                document.getElementById('edit_department_id').value = deptId;
                document.getElementById('edit_designation_remark').value = "";

                let prefix = window.location.pathname.startsWith('/admin') ? '/admin' : '/hr';
                document.getElementById('editDesignationForm').action = prefix + "/designations/" + id;
                openModal('editDesignationModal');
            }

            // Initialize AJAX Pagination
            let prefix = window.location.pathname.startsWith('/admin') ? '/admin' : '/hr';
            window.ajaxPagination = new AjaxPagination({
                endpoint: prefix + '/designations/data',
                containerSelector: '#designations-container',
                paginationSelector: '#designations-pagination',
                perPage: 15,
                renderCallback: function(designations) {
                    const container = document.querySelector('#designations-container');
                    
                    if (designations.length === 0) {
                        container.innerHTML = `
                            <tr>
                                <td colspan="5" class="text-center py-12">
                                    <div class="flex flex-col items-center gap-3">
                                        <div class="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center">
                                            <i class="fa-solid fa-briefcase text-2xl text-slate-400"></i>
                                        </div>
                                        <p class="text-slate-500 font-medium">No designations found</p>
                                    </div>
                                </td>
                            </tr>
                        `;
                        return;
                    }
                    
                    let html = '';
                    designations.forEach(designation => {
                        const department = designation.department;
                        
                        html += `
                            <tr>
                                <td><span class="font-mono text-sm font-semibold text-slate-600">#${designation.designation_id}</span></td>
                                <td><span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-50 text-indigo-800 text-sm font-bold">${designation.designation_code}</span></td>
                                <td><span class="font-semibold text-slate-800">${designation.designation_name}</span></td>
                                <td>
                                    ${department ? `
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-50 text-purple-700 text-sm font-medium">
                                            <i class="fa-solid fa-building text-xs"></i>
                                            ${department.department_name}
                                        </span>
                                    ` : '<span class="text-red-400 text-sm italic">No Department</span>'}
                                </td>
                                <td>
                                    <div class="flex items-center justify-center">
                                        <button onclick="editDesignation(${designation.designation_id}, '${designation.designation_code.replace(/'/g, "\\'")}', '${designation.designation_name.replace(/'/g, "\\'")}', ${designation.department_id || 0})"
                                                class="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center hover:scale-110 transition-all shadow-md"
                                                title="Edit">
                                            <i class="fa-solid fa-pen text-sm"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    });
                    
                    container.innerHTML = html;
                }
            });

            // Render initial pagination on page load
            <?php if($designations->hasPages()): ?>
                window.ajaxPagination.renderPagination({
                    current_page: <?php echo e($designations->currentPage()); ?>,
                    last_page: <?php echo e($designations->lastPage()); ?>,
                    from: <?php echo e($designations->firstItem() ?? 0); ?>,
                    to: <?php echo e($designations->lastItem() ?? 0); ?>,
                    total: <?php echo e($designations->total()); ?>

                });
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\manchester\resources\views/hr/designations/index.blade.php ENDPATH**/ ?>