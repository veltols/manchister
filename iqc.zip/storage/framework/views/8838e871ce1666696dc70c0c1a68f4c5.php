<?php $__env->startSection('title', 'Manage Users'); ?>
<?php $__env->startSection('subtitle', 'System user accounts and access control'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6 animate-fade-in-up">
        
        <!-- Header -->
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-2xl font-display font-bold text-premium">System Users</h2>
                <p class="text-sm text-slate-500 mt-1"><?php echo e($users->total()); ?> registered users</p>
            </div>
            <!-- Create Button -->
            <button onclick="openModal('newUserModal')" 
                class="inline-flex items-center gap-2 px-6 py-3 premium-button bg-gradient-brand text-white font-semibold rounded-xl shadow-lg hover:shadow-brand/20 hover:scale-105 transition-all duration-200">
                <i class="fa-solid fa-plus"></i>
                <span>Add New User</span>
            </button>
        </div>

        <!-- Users List -->
        <div class="premium-card overflow-hidden">
            <div class="overflow-x-auto">
                <table class="premium-table w-full">
                    <thead>
                        <tr>
                            <th class="text-left w-24">IQC ID</th>
                            <th class="text-left">Employee Name</th>
                            <th class="text-left">Email / Login ID</th>
                            <th class="text-left">Department</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="users-container">
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="font-mono text-sm font-semibold text-slate-600"><?php echo e($user->employee_no); ?></span>
                                </td>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                                            <?php echo e(substr($user->first_name, 0, 1)); ?><?php echo e(substr($user->last_name, 0, 1)); ?>

                                        </div>
                                        <div>
                                            <p class="font-semibold text-slate-800"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>
                                            <p class="text-xs text-slate-400"><?php echo e($user->designation->designation_name ?? 'Employee'); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-slate-600"><?php echo e($user->employee_email); ?></td>
                                <td>
                                    <?php if($user->department): ?>
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-50 text-purple-700 text-xs font-medium border border-purple-100/50">
                                            <i class="fa-solid fa-building text-[10px] opacity-70"></i>
                                            <?php echo e($user->department->department_name); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-md bg-slate-50 border border-slate-100 text-slate-400 text-xs font-medium italic">
                                            Unassigned
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full <?php echo e($user->is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'); ?> text-xs font-bold">
                                        <i class="fa-solid fa-circle text-[8px]"></i>
                                        <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td class="text-center">
                                    <div class="flex items-center justify-center gap-2">
                                        <a href="<?php echo e(route('admin.users.show', $user->employee_id)); ?>" 
                                           class="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center hover:scale-110 transition-all shadow-md"
                                           title="View Details">
                                            <i class="fa-solid fa-eye text-sm"></i>
                                        </a>
                                       
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-12 text-slate-500">
                                    No users found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- AJAX Pagination Container -->
            <div id="users-pagination"></div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/ajax-pagination.js')); ?>"></script>
        <script>
            function closeModal(id) {
                document.getElementById(id).classList.remove('active');
            }
            function openModal(id) {
                document.getElementById(id).classList.add('active');
            }

            // Status Badge Helper
            function getStatusBadge(isActive) {
                if (isActive) {
                    return `
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">
                            <i class="fa-solid fa-circle text-[8px]"></i>
                            Active
                        </span>
                    `;
                }
                return `
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-500 text-xs font-bold">
                        <i class="fa-solid fa-circle text-[8px]"></i>
                        Inactive
                    </span>
                `;
            }

            // Department Badge Helper
            function getDeptBadge(dept) {
                if (dept) {
                    return `
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-50 text-purple-700 text-xs font-medium border border-purple-100/50">
                            <i class="fa-solid fa-building text-[10px] opacity-70"></i>
                            ${dept.department_name}
                        </span>
                    `;
                }
                return `
                    <span class="inline-flex items-center px-2.5 py-1 rounded-md bg-slate-50 border border-slate-100 text-slate-400 text-xs font-medium italic">
                        Unassigned
                    </span>
                `;
            }

            // Initialize AJAX Pagination
            const prefix = "<?php echo e(route('admin.users.index')); ?>".replace('/users', ''); // Get base admin URL
            
            window.ajaxPagination = new AjaxPagination({
                endpoint: "<?php echo e(route('admin.users.data')); ?>",
                containerSelector: '#users-container',
                paginationSelector: '#users-pagination',
                perPage: 15,
                renderCallback: function(users) {
                    const container = document.querySelector('#users-container');
                    
                    if (users.length === 0) {
                        container.innerHTML = `
                            <tr>
                                <td colspan="6" class="text-center py-12 text-slate-500">
                                    No users found.
                                </td>
                            </tr>
                        `;
                        return;
                    }
                    
                    let html = '';
                    users.forEach(user => {
                        const firstInitial = user.first_name ? user.first_name.substring(0, 1) : '';
                        const lastInitial = user.last_name ? user.last_name.substring(0, 1) : '';
                        const designationName = user.designation ? user.designation.designation_name : 'Employee';
                        const showUrl = `<?php echo e(route('admin.users.show', ':id')); ?>`.replace(':id', user.employee_id);

                        html += `
                            <tr>
                                <td>
                                    <span class="font-mono text-sm font-semibold text-slate-600">${user.employee_no || ''}</span>
                                </td>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                                            ${firstInitial}${lastInitial}
                                        </div>
                                        <div>
                                            <p class="font-semibold text-slate-800">${user.first_name} ${user.last_name}</p>
                                            <p class="text-xs text-slate-400">${designationName}</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-slate-600">${user.employee_email}</td>
                                <td>
                                    ${getDeptBadge(user.department)}
                                </td>
                                <td class="text-center">
                                    ${getStatusBadge(user.is_active)}
                                </td>
                                <td class="text-center">
                                    <div class="flex items-center justify-center gap-2">
                                        <a href="${showUrl}" 
                                           class="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center hover:scale-110 transition-all shadow-md"
                                           title="View Details">
                                            <i class="fa-solid fa-eye text-sm"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        `;
                    });
                    
                    container.innerHTML = html;
                }
            });

            // Render initial pagination on page load
            <?php if($users->hasPages()): ?>
                window.ajaxPagination.renderPagination({
                    current_page: <?php echo e($users->currentPage()); ?>,
                    last_page: <?php echo e($users->lastPage()); ?>,
                    from: <?php echo e($users->firstItem() ?? 0); ?>,
                    to: <?php echo e($users->lastItem() ?? 0); ?>,
                    total: <?php echo e($users->total()); ?>

                });
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>

    <!-- New User Modal -->
    <div id="newUserModal" class="modal">
        <div class="modal-backdrop" onclick="closeModal('newUserModal')"></div>
        <div class="modal-content max-w-2xl p-6">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h2 class="text-2xl font-display font-bold text-premium">Add New User</h2>
                    <p class="text-slate-500 text-sm">Create a new system user account</p>
                </div>
                <button onclick="closeModal('newUserModal')" class="w-10 h-10 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors">
                    <i class="fa-solid fa-times text-xl"></i>
                </button>
            </div>

            <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="space-y-5">
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="md:col-span-1">
                            <label class="block text-sm font-semibold text-slate-700 mb-2">IQC ID</label>
                            <input type="text" name="employee_no" required class="premium-input w-full px-4 py-3 text-sm" placeholder="e.g. 1045">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-semibold text-slate-700 mb-2">Department</label>
                            <select name="department_id" required class="premium-input w-full px-4 py-3 text-sm">
                                <option value="">Select Department...</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->department_id); ?>"><?php echo e($dept->department_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 mb-2">First Name</label>
                            <input type="text" name="first_name" required class="premium-input w-full px-4 py-3 text-sm" placeholder="John">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 mb-2">Last Name</label>
                            <input type="text" name="last_name" required class="premium-input w-full px-4 py-3 text-sm" placeholder="Doe">
                        </div>
                    </div>

                    <div class="border-t border-slate-100 pt-4 mt-2">
                        <h3 class="text-sm font-bold text-indigo-900 mb-4">Login Credentials</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-semibold text-slate-700 mb-2">Email / Login ID</label>
                                <input type="email" name="employee_email" required class="premium-input w-full px-4 py-3 text-sm" placeholder="john.doe@company.com">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-slate-700 mb-2">Password</label>
                                <input type="password" name="password" required class="premium-input w-full px-4 py-3 text-sm" placeholder="••••••••">
                            </div>
                        </div>
                    </div>

                </div>

                <div class="flex justify-end gap-3 mt-8 pt-6 border-t border-slate-200">
                    <button type="button" onclick="closeModal('newUserModal')" class="px-6 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold transition-colors">
                        Cancel
                    </button>
                    <button type="submit" class="px-6 py-2.5 premium-button from-indigo-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200">
                        <i class="fa-solid fa-user-plus mr-2"></i>Create User
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\manchester\resources\views/admin/users/index.blade.php ENDPATH**/ ?>