<?php /** @var \App\Models\User $user */ $user = Auth::user(); ?>

<aside class="sidebar-gradient w-56 flex-shrink-0 flex flex-col text-white shadow-2xl relative z-20 hidden md:flex">
    <!-- Logo Area -->
    <div class="h-20 flex items-center justify-center border-b border-white/10 px-2 text-center">
        <a href="<?php echo e(route('dashboard')); ?>">
            <?php
                $sLogoPath = \App\Models\AppSetting::where('key', 'logo_path')->value('value');
                $sLogoUrl = $sLogoPath ? asset('uploads/' . $sLogoPath) : asset('images/logo.png');
            ?>
            <img src="<?php echo e($sLogoUrl); ?>" alt="IQC Logo" class="w-12 h-12 object-contain">
        </a>
    </div>

    <!-- Navigation -->
    <nav class="flex-1 flex flex-col py-6 px-3">
        <?php if($user && in_array($user->user_type, ['emp', 'eqa'])): ?>
            <?php echo $__env->make('layouts.sidebar.menus.emp', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($user && in_array($user->user_type, ['hr', 'admin_hr', 'sys_admin', 'root', 'eqa'])): ?>
            <?php echo $__env->make('layouts.sidebar.menus.manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </nav>

</aside><?php /**PATH E:\xampp\htdocs\manchester\resources\views/layouts/sidebar/index.blade.php ENDPATH**/ ?>